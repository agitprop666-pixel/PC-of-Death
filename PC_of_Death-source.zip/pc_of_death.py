#!/usr/bin/env python3
"""
PC of Death — Windows Security Vulnerability Scanner
Death's Head Software
"""
from __future__ import annotations

import os
import sys
import socket
import platform
import subprocess
import time
import ctypes
import re
from datetime import datetime
from pathlib import Path

# ── Windows-only guard ────────────────────────────────────────────────────────
if platform.system() != "Windows":
    print("PC of Death is a Windows-only tool.")
    sys.exit(1)

import winreg  # noqa: E402 — Windows-only

from PyQt6.QtCore import Qt, QThread, pyqtSignal
from PyQt6.QtGui import (
    QBrush, QColor, QFont, QIcon, QPainter, QPixmap
)
from PyQt6.QtWidgets import (
    QApplication, QFileDialog, QFrame, QHBoxLayout,
    QLabel, QMainWindow, QMessageBox, QPlainTextEdit,
    QProgressBar, QSplashScreen, QStatusBar, QTabWidget,
    QTextEdit, QTreeWidget, QTreeWidgetItem, QVBoxLayout,
    QWidget,
)

# =============================================================================
# Globals
# =============================================================================

APP_NAME    = "PC of Death"
ORG_NAME    = "Death's Head Software"
APP_VERSION = "1.0.0"


def resource_path(rel: str) -> str:
    base = getattr(sys, "_MEIPASS", Path(__file__).parent)
    return str(Path(base) / rel)


# Windows taskbar identity
try:
    ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID(
        f"DeathsHeadSoftware.PCofDeath.{APP_VERSION}"
    )
except Exception:
    pass


# =============================================================================
# Splash Screen
# =============================================================================

def create_splash() -> QSplashScreen | None:
    try:
        splash_path = Path(resource_path("splash.png"))
        if splash_path.exists():
            pixmap = QPixmap(str(splash_path))
            if pixmap.isNull():
                pixmap = QPixmap(800, 600)
                pixmap.fill(QColor(20, 20, 20))
            if pixmap.width() != 800 or pixmap.height() != 600:
                pixmap = pixmap.scaled(
                    800, 600,
                    Qt.AspectRatioMode.KeepAspectRatio,
                    Qt.TransformationMode.SmoothTransformation,
                )
        else:
            pixmap = QPixmap(800, 600)
            pixmap.fill(QColor(20, 20, 20))
            painter = QPainter(pixmap)
            painter.setPen(QColor(255, 255, 255))
            painter.setFont(QFont("Courier", 14))
            skull = [
                "        ___________     ",
                "       /           \\   ",
                "      |  O       O  |  ",
                "      |      ^      |  ",
                "      |   \\_____/   |  ",
                "       \\_         _/   ",
                "         |_______|     ",
            ]
            for i, line in enumerate(skull):
                painter.drawText(250, 250 + i * 25, line)
            painter.end()

        # Overlay title and footer
        painter = QPainter(pixmap)
        painter.setPen(QColor(255, 255, 255))
        painter.setFont(QFont("Courier", 38, QFont.Weight.Bold))
        tr = pixmap.rect(); tr.setTop(40); tr.setBottom(100)
        painter.drawText(
            tr, Qt.AlignmentFlag.AlignCenter | Qt.AlignmentFlag.AlignVCenter,
            APP_NAME,
        )
        painter.setFont(QFont("Courier", 14, QFont.Weight.Bold))
        fr = pixmap.rect()
        fr.setTop(pixmap.height() - 100)
        fr.setBottom(pixmap.height() - 50)
        painter.drawText(
            fr, Qt.AlignmentFlag.AlignCenter | Qt.AlignmentFlag.AlignVCenter,
            ORG_NAME,
        )
        painter.end()

        return QSplashScreen(pixmap, Qt.WindowType.WindowStaysOnTopHint)
    except Exception as e:
        print("Splash error:", e)
        return None


# =============================================================================
# Dark Stylesheet
# =============================================================================

DARK_STYLE = """
QMainWindow, QWidget {
    background-color: #0d0d0d;
    color: #e0e0e0;
    font-family: "Segoe UI";
    font-size: 10pt;
}
QTabWidget::pane {
    border: 1px solid #3a0000;
    background: #111111;
}
QTabBar::tab {
    background: #1a0000;
    color: #886666;
    padding: 8px 18px;
    border: 1px solid #3a0000;
    border-bottom: none;
    font-family: "Courier New";
    font-size: 10pt;
}
QTabBar::tab:selected {
    background: #2a0000;
    color: #ff4444;
    border-bottom: 2px solid #cc0000;
}
QTabBar::tab:hover:!selected {
    background: #200000;
    color: #cc4444;
}
QPushButton {
    background-color: #1a0000;
    color: #cc3333;
    border: 1px solid #3a0000;
    border-radius: 3px;
    padding: 7px 18px;
    font-family: "Courier New";
    font-size: 10pt;
    font-weight: bold;
}
QPushButton:hover {
    background-color: #2a0000;
    color: #ff5555;
    border-color: #cc0000;
}
QPushButton:pressed  { background-color: #400000; }
QPushButton:disabled { color: #444; border-color: #222; background-color: #111; }
QPlainTextEdit, QTextEdit {
    background-color: #080808;
    color: #cccccc;
    border: 1px solid #2a0000;
    font-family: "Consolas";
    font-size: 10pt;
    selection-background-color: #440000;
}
QTreeWidget {
    background-color: #080808;
    color: #cccccc;
    border: 1px solid #2a0000;
    alternate-background-color: #0f0f0f;
    gridline-color: #1a0000;
    font-size: 10pt;
}
QTreeWidget::item:selected { background-color: #2a0000; color: #ff6666; }
QTreeWidget::item:hover    { background-color: #180000; }
QHeaderView::section {
    background-color: #1a0000;
    color: #cc3333;
    border: 1px solid #3a0000;
    padding: 5px;
    font-family: "Courier New";
    font-weight: bold;
}
QProgressBar {
    background-color: #111;
    border: 1px solid #3a0000;
    border-radius: 3px;
    text-align: center;
    color: #cc3333;
    font-family: "Courier New";
    font-size: 9pt;
}
QProgressBar::chunk { background-color: #cc0000; }
QStatusBar {
    background-color: #0a0000;
    color: #884444;
    border-top: 1px solid #3a0000;
    font-family: "Courier New";
    font-size: 9pt;
}
QScrollBar:vertical {
    background: #0d0d0d; width: 10px; border: none;
}
QScrollBar::handle:vertical {
    background: #3a0000; border-radius: 4px; min-height: 20px;
}
QScrollBar::handle:vertical:hover { background: #cc0000; }
QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical { height: 0; }
QScrollBar:horizontal {
    background: #0d0d0d; height: 10px; border: none;
}
QScrollBar::handle:horizontal {
    background: #3a0000; border-radius: 4px; min-width: 20px;
}
QScrollBar::handle:horizontal:hover { background: #cc0000; }
QScrollBar::add-line:horizontal, QScrollBar::sub-line:horizontal { width: 0; }
QLabel#header {
    color: #cc3333;
    font-family: "Courier New";
    font-size: 16pt;
    font-weight: bold;
}
QLabel#subtitle {
    color: #ffffff;
    font-family: "Courier New";
    font-size: 9pt;
}
QFrame#separator {
    background-color: #3a0000;
    max-height: 1px;
}
"""

# =============================================================================
# Scanner Backend  (QThread)
# =============================================================================

SEV_COLORS = {
    "high":   QColor(255, 60,  60),
    "medium": QColor(255, 160, 30),
    "low":    QColor(255, 220, 50),
    "info":   QColor(100, 180, 255),
}

CREATE_NO_WINDOW = 0x08000000


class SecurityScanner(QThread):
    """Runs all Windows security checks in a background thread."""

    sig_log      = pyqtSignal(str)
    sig_finding  = pyqtSignal(dict)
    sig_progress = pyqtSignal(int)
    sig_finished = pyqtSignal(dict)

    def __init__(self):
        super().__init__()
        self._stop = False
        self.results: dict = {
            "scan_time":       datetime.now().isoformat(),
            "system_info":     {},
            "vulnerabilities": [],
            "warnings":        [],
            "info":            [],
            "recommendations": [],
        }
        self._checks = [
            ("System Info",          self._check_system_info),
            ("Windows Defender/AV",  self._check_defender),
            ("Windows Firewall",     self._check_firewall),
            ("Windows Update",       self._check_windows_update),
            ("SMBv1 (EternalBlue)",  self._check_smbv1),
            ("Remote Desktop (RDP)", self._check_rdp),
            ("User Account Control", self._check_uac),
            ("Guest Account",        self._check_guest_account),
            ("Password Policy",      self._check_password_policy),
            ("BitLocker Encryption", self._check_bitlocker),
            ("Secure Boot",          self._check_secure_boot),
            ("Open Ports",           self._check_open_ports),
            ("Admin Shares",         self._check_admin_shares),
            ("Remote Registry",      self._check_remote_registry),
            ("AutoRun / AutoPlay",   self._check_autorun),
            ("Startup Entries",      self._check_startup_entries),
            ("Environment Secrets",  self._check_env_secrets),
            ("Credential Guard",     self._check_credential_guard),
            ("LSA / PPL Protection", self._check_lsa_protection),
            ("Spectre/Meltdown",     self._check_speculation_control),
        ]

    def stop(self):
        self._stop = True

    # ── Helpers ───────────────────────────────────────────────────────────────

    def _log(self, msg: str):
        self.sig_log.emit(msg)

    def _finding(self, category: str, severity: str, ftype: str,
                 description: str, recommendation: str = ""):
        item = {
            "category":       category,
            "severity":       severity,
            "type":           ftype,
            "description":    description,
            "recommendation": recommendation,
        }
        bucket = "vulnerabilities" if severity == "high" else (
            "warnings" if severity in ("medium", "low") else "info"
        )
        self.results[bucket].append(item)
        self.sig_finding.emit(item)

    def _ps(self, command: str, timeout: int = 15) -> str:
        """Run a PowerShell command, return stdout (stripped)."""
        try:
            r = subprocess.run(
                ["powershell", "-NonInteractive", "-NoProfile", "-Command", command],
                capture_output=True, text=True, timeout=timeout,
                creationflags=CREATE_NO_WINDOW,
            )
            return r.stdout.strip()
        except Exception:
            return ""

    def _cmd(self, args: list[str], timeout: int = 10) -> str:
        """Run a command-line tool, return stdout (stripped)."""
        try:
            r = subprocess.run(
                args, capture_output=True, text=True, timeout=timeout,
                creationflags=CREATE_NO_WINDOW,
            )
            return r.stdout.strip()
        except Exception:
            return ""

    def _reg_get(self, hive, path: str, name: str):
        """Read a single registry value; returns None on failure."""
        try:
            key = winreg.OpenKey(hive, path)
            val, _ = winreg.QueryValueEx(key, name)
            winreg.CloseKey(key)
            return val
        except (FileNotFoundError, OSError, PermissionError):
            return None

    # ── Individual Checks ─────────────────────────────────────────────────────

    def _check_system_info(self):
        self._log("[*] Gathering system information…")
        info: dict[str, str] = {
            "Hostname":    socket.gethostname(),
            "OS":          platform.system(),
            "Release":     platform.release(),
            "Version":     platform.version(),
            "Architecture": platform.machine(),
            "Processor":   platform.processor(),
            "Python":      platform.python_version(),
        }
        edition = self._ps("(Get-CimInstance Win32_OperatingSystem).Caption")
        if edition:
            info["Edition"] = edition
        uptime = self._ps(
            "((Get-Date)-(gcim Win32_OperatingSystem).LastBootUpTime)"
            ".TotalHours"
        )
        if uptime:
            try:
                info["Uptime (hours)"] = f"{float(uptime):.1f}"
            except ValueError:
                pass
        self.results["system_info"] = info
        for k, v in info.items():
            self._log(f"    {k}: {v}")

    def _check_defender(self):
        self._log("[*] Checking Windows Defender / antivirus status…")
        out = self._ps(
            "Get-MpComputerStatus | "
            "Select-Object AntivirusEnabled,RealTimeProtectionEnabled,"
            "AntivirusSignatureAge | Format-List"
        )
        if not out:
            self._finding("Antivirus", "medium", "av_query_failed",
                "Could not query Windows Defender (elevation may be required)",
                "Run PC of Death as Administrator for full AV results.")
            return

        av_on  = re.search(r'AntivirusEnabled\s*:\s*True',  out, re.I) is not None
        rtp_on = re.search(r'RealTimeProtectionEnabled\s*:\s*True', out, re.I) is not None

        if not av_on:
            self._finding("Antivirus", "high", "antivirus_disabled",
                "Windows Defender antivirus is DISABLED",
                "Enable Defender or install a reputable third-party AV solution.")
        else:
            self._log("    [+] Antivirus enabled")

        if not rtp_on:
            self._finding("Antivirus", "high", "realtime_protection_disabled",
                "Real-time protection is DISABLED",
                "Enable real-time protection in Windows Security settings.")
        else:
            self._log("    [+] Real-time protection enabled")

        age_m = re.search(r'AntivirusSignatureAge\s*:\s*(\d+)', out)
        if age_m:
            age = int(age_m.group(1))
            self._log(f"    [*] Signature age: {age} days")
            if age > 7:
                self._finding("Antivirus", "medium", "stale_av_signatures",
                    f"Antivirus signatures are {age} days old",
                    "Update Windows Defender definitions immediately.")

    def _check_firewall(self):
        self._log("[*] Checking Windows Firewall status…")
        out = self._cmd(["netsh", "advfirewall", "show", "allprofiles"])
        current = None
        for line in out.splitlines():
            for profile in ("Domain", "Private", "Public"):
                if profile in line and "Profile" in line:
                    current = profile
            if current and "State" in line:
                if "OFF" in line.upper():
                    self._finding("Firewall", "high",
                        f"firewall_{current.lower()}_disabled",
                        f"Windows Firewall is DISABLED for the {current} profile",
                        f"Run: netsh advfirewall set {current.lower()}profile state on")
                elif "ON" in line.upper():
                    self._log(f"    [+] Firewall ON ({current} profile)")
                current = None

    def _check_windows_update(self):
        self._log("[*] Checking Windows Update status…")
        # Count pending software updates
        pending = self._ps(
            "try { (New-Object -ComObject Microsoft.Update.Session)"
            ".CreateUpdateSearcher()"
            ".Search('IsInstalled=0 and Type=\\'Software\\'').Updates.Count }"
            " catch { 'ERR' }",
            timeout=30,
        )
        if pending.isdigit():
            count = int(pending)
            if count > 0:
                self._finding("Updates",
                    "high" if count > 10 else "medium",
                    "pending_windows_updates",
                    f"{count} Windows update(s) are pending installation",
                    "Install all updates via Settings → Windows Update.")
            else:
                self._log("    [+] System is fully up to date")
        else:
            # Fallback: check wuauserv state
            svc = self._ps("(Get-Service wuauserv).Status")
            if "Stopped" in svc:
                self._finding("Updates", "medium", "wuauserv_stopped",
                    "Windows Update service is stopped",
                    "Start the Windows Update service: net start wuauserv")
            else:
                self._log("    [*] Windows Update state could not be fully determined")

    def _check_smbv1(self):
        self._log("[*] Checking SMBv1 status (EternalBlue / WannaCry surface)…")
        out = self._ps("(Get-SmbServerConfiguration).EnableSMB1Protocol")
        if "True" in out:
            self._finding("Network", "high", "smbv1_enabled",
                "SMBv1 is ENABLED — system is vulnerable to EternalBlue/WannaCry",
                "Disable SMBv1: Set-SmbServerConfiguration -EnableSMB1Protocol $false -Force")
        elif "False" in out:
            self._log("    [+] SMBv1 is disabled")
        else:
            # Try feature query
            feat = self._ps(
                "Get-WindowsOptionalFeature -Online -FeatureName SMB1Protocol"
                " | Select-Object -ExpandProperty State"
            )
            if "Enabled" in feat:
                self._finding("Network", "high", "smbv1_feature_enabled",
                    "SMBv1 Windows Feature is ENABLED",
                    "Disable-WindowsOptionalFeature -Online -FeatureName SMB1Protocol")
            elif feat:
                self._log("    [+] SMBv1 feature is not enabled")
            else:
                self._log("    [!] Could not determine SMBv1 status")

    def _check_rdp(self):
        self._log("[*] Checking Remote Desktop Protocol (RDP) settings…")
        fdeny = self._reg_get(
            winreg.HKEY_LOCAL_MACHINE,
            r"SYSTEM\CurrentControlSet\Control\Terminal Server",
            "fDenyTSConnections",
        )
        if fdeny is None:
            self._log("    [!] Could not read RDP registry key (elevation required)")
            return
        if fdeny != 0:
            self._log("    [+] RDP is disabled")
            return

        self._log("    [*] RDP is enabled")
        # Check NLA
        nla = self._reg_get(
            winreg.HKEY_LOCAL_MACHINE,
            r"SYSTEM\CurrentControlSet\Control\Terminal Server\WinStations\RDP-Tcp",
            "UserAuthenticationRequired",
        )
        if nla == 0:
            self._finding("Remote Access", "high", "rdp_no_nla",
                "RDP is enabled WITHOUT Network Level Authentication (NLA)",
                "Enable NLA: set UserAuthenticationRequired=1 in RDP-Tcp registry key.")
        else:
            self._log("    [+] RDP NLA is enabled")
            self._finding("Remote Access", "medium", "rdp_enabled",
                "RDP is enabled — ensure it is firewalled and MFA-protected",
                "Restrict RDP to specific IPs in Windows Firewall; use MFA.")

    def _check_uac(self):
        self._log("[*] Checking User Account Control (UAC)…")
        uac = self._reg_get(
            winreg.HKEY_LOCAL_MACHINE,
            r"SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System",
            "EnableLUA",
        )
        consent = self._reg_get(
            winreg.HKEY_LOCAL_MACHINE,
            r"SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System",
            "ConsentPromptBehaviorAdmin",
        )
        if uac is None:
            self._log("    [!] Could not read UAC settings")
            return
        if uac == 0:
            self._finding("Access Control", "high", "uac_disabled",
                "User Account Control (UAC) is DISABLED",
                "Enable UAC: set EnableLUA=1 in HKLM\\...\\Policies\\System.")
        else:
            self._log("    [+] UAC is enabled")
            if consent == 0:
                self._finding("Access Control", "medium", "uac_no_prompt",
                    "UAC is set to 'Never notify' — elevation occurs without prompt",
                    "Set UAC to at least 'Notify only when apps make changes'.")

    def _check_guest_account(self):
        self._log("[*] Checking Guest account status…")
        out = self._cmd(["net", "user", "Guest"])
        m = re.search(r"Account active\s+(\w+)", out, re.I)
        if m:
            if m.group(1).lower() == "yes":
                self._finding("User Accounts", "high", "guest_account_active",
                    "The built-in Guest account is ENABLED",
                    "Disable it: net user Guest /active:no")
            else:
                self._log("    [+] Guest account is disabled")
        else:
            self._log("    [!] Could not determine Guest account status")

    def _check_password_policy(self):
        self._log("[*] Checking local password policy…")
        out = self._cmd(["net", "accounts"])
        if not out:
            self._log("    [!] Could not query password policy")
            return

        min_len = re.search(r"Minimum password length\s+(\d+)", out, re.I)
        if min_len:
            length = int(min_len.group(1))
            self._log(f"    [*] Min password length: {length}")
            if length < 8:
                self._finding("Password Policy", "high", "weak_min_password_length",
                    f"Minimum password length is only {length} characters",
                    "Set minimum password length to 12+ characters via Local Security Policy.")

        max_age = re.search(r"Maximum password age \(days\)\s+(\S+)", out, re.I)
        if max_age:
            age_val = max_age.group(1)
            self._log(f"    [*] Max password age: {age_val} days")
            if age_val.lower() in ("unlimited", "never"):
                self._finding("Password Policy", "medium", "passwords_never_expire",
                    "Passwords are configured to NEVER expire",
                    "Set a max password age of 90 days.")
            else:
                try:
                    if int(age_val) > 90:
                        self._finding("Password Policy", "medium", "password_age_too_long",
                            f"Max password age is {age_val} days (> 90)",
                            "Reduce max password age to 90 days or less.")
                except ValueError:
                    pass

        lockout = re.search(r"Lockout threshold\s+(\S+)", out, re.I)
        if lockout:
            threshold = lockout.group(1)
            self._log(f"    [*] Lockout threshold: {threshold}")
            if threshold.lower() in ("never", "0"):
                self._finding("Password Policy", "medium", "no_account_lockout",
                    "Account lockout is NOT configured — brute-force attacks possible",
                    "Set lockout threshold to 5–10 failed attempts via Local Security Policy.")

    def _check_bitlocker(self):
        self._log("[*] Checking BitLocker drive encryption…")
        # PowerShell query
        status = self._ps(
            "try { (Get-BitLockerVolume -MountPoint $env:SystemDrive)"
            ".ProtectionStatus } catch { 'ERR' }"
        )
        if status == "1" or status.lower() == "on":
            self._log("    [+] BitLocker is ON for system drive")
            return
        if status == "0" or status.lower() == "off":
            self._finding("Encryption", "high", "bitlocker_disabled",
                "BitLocker is DISABLED on the system drive — data at rest is unencrypted",
                "Enable BitLocker: Settings → System → BitLocker Drive Encryption.")
            return
        # Fallback: manage-bde
        out = self._cmd(["manage-bde", "-status", "C:"])
        if "Protection On" in out:
            self._log("    [+] BitLocker protection is ON")
        elif "Protection Off" in out:
            self._finding("Encryption", "high", "bitlocker_disabled",
                "BitLocker is DISABLED on C: — data at rest is unencrypted",
                "Enable BitLocker via manage-bde or Windows Settings.")
        else:
            self._log("    [!] Could not determine BitLocker status")

    def _check_secure_boot(self):
        self._log("[*] Checking Secure Boot (UEFI) status…")
        out = self._ps("Confirm-SecureBootUEFI 2>$null")
        if "True" in out:
            self._log("    [+] Secure Boot is enabled")
        elif "False" in out:
            self._finding("Boot Security", "medium", "secure_boot_disabled",
                "Secure Boot is DISABLED",
                "Enable Secure Boot in UEFI / BIOS firmware settings.")
        else:
            self._log("    [*] Secure Boot status unavailable (non-UEFI or access denied)")

    def _check_open_ports(self):
        self._log("[*] Scanning for risky open local ports…")
        risky_ports: dict[int, tuple[str, str, str]] = {
            21:    ("FTP",           "high",   "Plaintext file transfer — credentials sniffable"),
            23:    ("Telnet",        "high",   "Plaintext remote shell — replace with SSH"),
            25:    ("SMTP",          "medium", "Open mail relay — potential spam/abuse vector"),
            135:   ("MSRPC",         "medium", "Windows RPC endpoint mapper — commonly targeted"),
            137:   ("NetBIOS-NS",    "medium", "NetBIOS name service — information leakage"),
            139:   ("NetBIOS-SSN",   "medium", "NetBIOS session service — legacy Windows sharing"),
            445:   ("SMB",           "medium", "SMB file sharing — verify patched and firewalled"),
            1433:  ("MSSQL",         "high",   "SQL Server exposed — restrict to localhost"),
            1434:  ("MSSQL Browser", "medium", "SQL Server Browser UDP discovery service"),
            3306:  ("MySQL",         "high",   "MySQL exposed — restrict to localhost"),
            3389:  ("RDP",           "high",   "Remote Desktop exposed — firewall and require MFA"),
            4444:  ("Metasploit",    "high",   "Default Metasploit listener — indicator of compromise"),
            5432:  ("PostgreSQL",    "high",   "PostgreSQL exposed — restrict to localhost"),
            5900:  ("VNC",           "high",   "VNC remote desktop — often weakly authenticated"),
            5985:  ("WinRM HTTP",    "medium", "Windows Remote Management over HTTP"),
            5986:  ("WinRM HTTPS",   "medium", "Windows Remote Management over HTTPS"),
            8080:  ("HTTP-Alt",      "low",    "Alternate HTTP port — identify what is serving"),
            8443:  ("HTTPS-Alt",     "low",    "Alternate HTTPS port — verify service"),
            9200:  ("Elasticsearch", "high",   "Elasticsearch — frequently exposed with no auth"),
            27017: ("MongoDB",       "high",   "MongoDB — frequently exposed with no auth"),
        }
        for port, (service, severity, desc) in risky_ports.items():
            if self._stop:
                return
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(0.4)
            if sock.connect_ex(("127.0.0.1", port)) == 0:
                self._log(f"    [!] Port {port} ({service}) OPEN")
                self._finding("Open Ports", severity, f"port_{port}_open",
                    f"Port {port} ({service}) is OPEN — {desc}",
                    f"Firewall or disable port {port} if not required.")
            else:
                self._log(f"    [-] Port {port} ({service}) closed")
            sock.close()

    def _check_admin_shares(self):
        self._log("[*] Checking default administrative shares…")
        auto = self._reg_get(
            winreg.HKEY_LOCAL_MACHINE,
            r"SYSTEM\CurrentControlSet\Services\LanmanServer\Parameters",
            "AutoShareWks",
        )
        if auto == 0:
            self._log("    [+] AutoShareWks is disabled (C$, ADMIN$ are off)")
        else:
            self._finding("Network", "low", "admin_shares_active",
                "Default admin shares (C$, ADMIN$) are active",
                "Disable via registry: "
                "HKLM\\...\\LanmanServer\\Parameters\\AutoShareWks=0")

    def _check_remote_registry(self):
        self._log("[*] Checking Remote Registry service…")
        start = self._reg_get(
            winreg.HKEY_LOCAL_MACHINE,
            r"SYSTEM\CurrentControlSet\Services\RemoteRegistry",
            "Start",
        )
        labels = {2: "Automatic", 3: "Manual", 4: "Disabled"}
        if start is None:
            self._log("    [+] Remote Registry service not found (likely disabled)")
        elif start == 2:
            self._finding("Remote Access", "medium", "remote_registry_auto",
                "Remote Registry service is set to AUTO-START",
                "Set Remote Registry to Disabled: sc config RemoteRegistry start= disabled")
        elif start == 3:
            self._finding("Remote Access", "low", "remote_registry_manual",
                "Remote Registry is set to Manual (not fully disabled)",
                "Consider disabling Remote Registry if not needed.")
        else:
            self._log(f"    [+] Remote Registry is {labels.get(start, 'Disabled')}")

    def _check_autorun(self):
        self._log("[*] Checking AutoRun / AutoPlay policy…")
        val = self._reg_get(
            winreg.HKEY_LOCAL_MACHINE,
            r"SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Explorer",
            "NoDriveTypeAutoRun",
        )
        if val is None:
            self._finding("AutoRun", "medium", "autorun_policy_absent",
                "AutoRun Group Policy is not configured (may be enabled for removable media)",
                "Set NoDriveTypeAutoRun=0xFF via Group Policy or registry.")
        elif val == 0xFF or val == 255:
            self._log("    [+] AutoRun disabled for all drive types")
        elif val == 0:
            self._finding("AutoRun", "medium", "autorun_fully_enabled",
                "AutoRun is ENABLED for all drive types — USB malware risk",
                "Set NoDriveTypeAutoRun=0xFF via Group Policy.")
        else:
            self._finding("AutoRun", "low", "autorun_partial",
                f"AutoRun partially disabled (NoDriveTypeAutoRun=0x{val:02X}) — some drives still auto-run",
                "Set NoDriveTypeAutoRun=0xFF to disable for all drive types.")

    def _check_startup_entries(self):
        self._log("[*] Checking startup registry entries for suspicious entries…")
        hives = [
            (winreg.HKEY_LOCAL_MACHINE,
             r"SOFTWARE\Microsoft\Windows\CurrentVersion\Run"),
            (winreg.HKEY_LOCAL_MACHINE,
             r"SOFTWARE\Microsoft\Windows\CurrentVersion\RunOnce"),
            (winreg.HKEY_CURRENT_USER,
             r"SOFTWARE\Microsoft\Windows\CurrentVersion\Run"),
        ]
        patterns = [
            r"\\temp\\", r"\\tmp\\",
            r"\.vbs$", r"\.bat$", r"\.cmd$",
            r"powershell.*-enc",
            r"cmd(\.exe)?.*[/\\]c\s",
            r"wscript", r"cscript", r"mshta",
            r"regsvr32.*scrobj",
        ]
        flagged = 0
        for hive, path in hives:
            try:
                key = winreg.OpenKey(hive, path)
                i = 0
                while True:
                    try:
                        name, value, _ = winreg.EnumValue(key, i)
                        self._log(f"    [*] Startup entry: {name} = {value[:80]}")
                        for pat in patterns:
                            if re.search(pat, value, re.IGNORECASE):
                                self._finding("Startup", "high", "suspicious_startup_entry",
                                    f"Suspicious startup entry '{name}': {value[:120]}",
                                    "Investigate and remove via Task Manager → Startup or regedit.")
                                flagged += 1
                                break
                        i += 1
                    except OSError:
                        break
                winreg.CloseKey(key)
            except (FileNotFoundError, OSError, PermissionError):
                continue
        if flagged == 0:
            self._log("    [+] No obviously suspicious startup entries detected")

    def _check_env_secrets(self):
        self._log("[*] Checking environment variables for exposed credentials…")
        sensitive = [
            "password", "passwd", "secret", "api_key", "apikey",
            "token", "auth", "credential", "private_key",
            "aws_access", "aws_secret", "azure_client",
        ]
        found: list[str] = []
        for key in os.environ:
            kl = key.lower()
            if any(p in kl for p in sensitive):
                found.append(key)
                self._finding("Environment", "medium", "env_secret_exposed",
                    f"Potential credential in environment variable: {key}",
                    "Use a secrets manager (Azure Key Vault, HashiCorp Vault) — "
                    "never store credentials in environment variables.")
        if not found:
            self._log("    [+] No obvious credentials in environment variables")

    def _check_credential_guard(self):
        self._log("[*] Checking Credential Guard / Device Guard status…")
        out = self._ps(
            "try { (Get-CimInstance -ClassName Win32_DeviceGuard "
            "-Namespace root\\Microsoft\\Windows\\DeviceGuard)"
            ".SecurityServicesRunning } catch { 'ERR' }"
        )
        if out and out != "ERR" and re.search(r"[12]", out):
            self._log("    [+] Credential Guard / Device Guard is active")
        elif out == "ERR" or not out:
            self._log("    [!] Could not query Device Guard (may need elevation)")
        else:
            self._finding("Credential Protection", "medium", "credential_guard_inactive",
                "Credential Guard is not running — LSASS credentials are more exposed",
                "Enable via Device Guard Group Policy or Windows Security settings.")

    def _check_lsa_protection(self):
        self._log("[*] Checking LSA RunAsPPL (Protected Process Light)…")
        val = self._reg_get(
            winreg.HKEY_LOCAL_MACHINE,
            r"SYSTEM\CurrentControlSet\Control\Lsa",
            "RunAsPPL",
        )
        if val == 1:
            self._log("    [+] LSA Protected Process Light (PPL) is enabled")
        elif val == 0:
            self._finding("Credential Protection", "medium", "lsa_ppl_disabled",
                "LSA RunAsPPL is explicitly DISABLED — LSASS memory is dumpable (Mimikatz risk)",
                "Enable: HKLM\\SYSTEM\\CurrentControlSet\\Control\\Lsa\\RunAsPPL=1")
        else:
            self._finding("Credential Protection", "medium", "lsa_ppl_not_set",
                "LSA RunAsPPL is not configured — LSASS may be vulnerable to credential dumping",
                "Set HKLM\\SYSTEM\\CurrentControlSet\\Control\\Lsa\\RunAsPPL=1 and reboot.")

    def _check_speculation_control(self):
        self._log("[*] Checking Spectre / Meltdown CPU mitigations…")
        out = self._ps(
            "try { Get-SpeculationControlSettings 2>$null | "
            "Select-Object BTIWindowsSupportEnabled,KVAShadowWindowsSupportEnabled "
            "| Format-List } catch { 'NOMODULE' }"
        )
        if "NOMODULE" in out or not out:
            self._log(
                "    [*] SpeculationControl module not installed — "
                "install via: Install-Module SpeculationControl"
            )
            return
        enabled = re.findall(r":\s*True", out)
        if len(enabled) >= 2:
            self._log("    [+] BTI and KVA Shadow mitigations are enabled")
        else:
            self._finding("CPU Mitigations", "medium", "speculation_control_incomplete",
                "Spectre / Meltdown mitigations appear incomplete or disabled",
                "Apply all Windows patches and update CPU firmware / microcode.")

    def _generate_recommendations(self):
        recs = [
            "Keep Windows and all software updated — enable automatic updates",
            "Use a password manager and enable MFA on every account",
            "Regularly back up data (offline + cloud), and test restores",
            "Limit admin accounts — use standard user for day-to-day tasks",
            "Enable audit logging and review Windows Event Viewer regularly",
            "Segment your network — isolate critical and IoT devices",
            "Use Windows Hello or hardware security keys where possible",
            "Run periodic vulnerability scans and act on findings promptly",
            "Enable Microsoft Defender Application Control (WDAC) in enterprises",
            "Subscribe to CISA Known Exploited Vulnerabilities (KEV) alerts",
        ]
        if len(self.results["vulnerabilities"]) > 5:
            recs.insert(0, "URGENT: You have multiple HIGH findings — address them immediately")
        self.results["recommendations"] = recs

    # ── Thread Entry ──────────────────────────────────────────────────────────

    def run(self):
        self._log("=" * 62)
        self._log(f"  {APP_NAME}  —  {ORG_NAME}")
        self._log(f"  Scan started: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        self._log("=" * 62)
        self._log("")

        total = len(self._checks)
        for i, (name, fn) in enumerate(self._checks):
            if self._stop:
                self._log("\n[!] Scan aborted by user.")
                break
            self._log(f"\n── {name} {'─' * max(1, 50 - len(name))}")
            try:
                fn()
            except Exception as exc:
                self._log(f"    [!] Unexpected error in '{name}': {exc}")
            self.sig_progress.emit(int((i + 1) / total * 100))

        self._generate_recommendations()
        self._log("")
        self._log("=" * 62)
        self._log(
            f"  DONE — "
            f"{len(self.results['vulnerabilities'])} vulnerabilities  |  "
            f"{len(self.results['warnings'])} warnings"
        )
        self._log("=" * 62)
        self.sig_finished.emit(self.results)


# =============================================================================
# Main Window
# =============================================================================

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle(f"{APP_NAME}  —  {ORG_NAME}")
        self.setMinimumSize(900, 650)
        self.resize(1200, 800)

        icon_path = resource_path("splash.png")
        if Path(icon_path).exists():
            self.setWindowIcon(QIcon(icon_path))

        self._scanner: SecurityScanner | None = None
        self._results: dict | None = None
        self._build_ui()

    # ── Layout ────────────────────────────────────────────────────────────────

    def _build_ui(self):
        central = QWidget()
        self.setCentralWidget(central)
        root = QVBoxLayout(central)
        root.setContentsMargins(12, 12, 12, 6)
        root.setSpacing(8)

        # Header row
        hdr = QHBoxLayout()
        title = QLabel(f"☠  {APP_NAME}")
        title.setObjectName("header")
        sub = QLabel(f"{ORG_NAME}  ·  v{APP_VERSION}")
        sub.setObjectName("subtitle")
        hdr.addWidget(title)
        hdr.addStretch()
        hdr.addWidget(sub)
        root.addLayout(hdr)

        # Divider
        div = QFrame()
        div.setObjectName("separator")
        div.setFrameShape(QFrame.Shape.HLine)
        div.setFixedHeight(1)
        root.addWidget(div)

        # Toolbar
        bar = QHBoxLayout()
        bar.setSpacing(6)
        self.btn_scan  = self._btn("▶  START SCAN")
        self.btn_stop  = self._btn("■  STOP")
        self.btn_save  = self._btn("💾  SAVE REPORT")
        self.btn_clear = self._btn("✕  CLEAR")
        self.btn_stop.setEnabled(False)
        self.btn_save.setEnabled(False)
        for b in (self.btn_scan, self.btn_stop, self.btn_save, self.btn_clear):
            bar.addWidget(b)
        bar.addStretch()
        root.addLayout(bar)

        # Tab widget
        self.tabs = QTabWidget()
        root.addWidget(self.tabs, 1)

        # Tab 0 — Live log
        self.log_view = QPlainTextEdit()
        self.log_view.setReadOnly(True)
        self.log_view.setPlaceholderText("Scan output will appear here…")
        self.tabs.addTab(self.log_view, "  Scan Log  ")

        # Tab 1 — Vulnerabilities
        self.vuln_tree = self._make_tree()
        self.tabs.addTab(self.vuln_tree, "  Vulnerabilities  ")

        # Tab 2 — Warnings
        self.warn_tree = self._make_tree()
        self.tabs.addTab(self.warn_tree, "  Warnings  ")

        # Tab 3 — Summary
        self.summary = QTextEdit()
        self.summary.setReadOnly(True)
        self.tabs.addTab(self.summary, "  Summary  ")

        # Progress bar
        self.progress = QProgressBar()
        self.progress.setRange(0, 100)
        self.progress.setValue(0)
        self.progress.setFixedHeight(14)
        root.addWidget(self.progress)

        # Status bar
        self.sb = QStatusBar()
        self.setStatusBar(self.sb)
        self.sb.showMessage("Ready — click  ▶ START SCAN  to begin")

        # Signals
        self.btn_scan.clicked.connect(self._start_scan)
        self.btn_stop.clicked.connect(self._stop_scan)
        self.btn_save.clicked.connect(self._save_report)
        self.btn_clear.clicked.connect(self._clear)

    @staticmethod
    def _btn(label: str) -> "QPushButton":
        from PyQt6.QtWidgets import QPushButton
        return QPushButton(label)

    @staticmethod
    def _make_tree() -> QTreeWidget:
        tree = QTreeWidget()
        tree.setColumnCount(4)
        tree.setHeaderLabels(["  Severity", "  Category", "  Type", "  Description"])
        tree.setAlternatingRowColors(True)
        tree.setRootIsDecorated(False)
        tree.setWordWrap(True)
        tree.header().setStretchLastSection(True)
        tree.setColumnWidth(0, 90)
        tree.setColumnWidth(1, 150)
        tree.setColumnWidth(2, 170)
        return tree

    # ── Scan Control ──────────────────────────────────────────────────────────

    def _start_scan(self):
        self._clear()
        self.btn_scan.setEnabled(False)
        self.btn_stop.setEnabled(True)
        self.btn_save.setEnabled(False)
        self.progress.setValue(0)
        self.sb.showMessage("Scanning — please wait…")
        self.tabs.setCurrentIndex(0)

        self._scanner = SecurityScanner()
        self._scanner.sig_log.connect(self._on_log)
        self._scanner.sig_finding.connect(self._on_finding)
        self._scanner.sig_progress.connect(self.progress.setValue)
        self._scanner.sig_finished.connect(self._on_finished)
        self._scanner.start()

    def _stop_scan(self):
        if self._scanner:
            self._scanner.stop()
        self.btn_stop.setEnabled(False)
        self.sb.showMessage("Stopping scan…")

    # ── Slots ─────────────────────────────────────────────────────────────────

    def _on_log(self, msg: str):
        self.log_view.appendPlainText(msg)

    def _on_finding(self, item: dict):
        sev   = item["severity"]
        color = SEV_COLORS.get(sev, QColor(200, 200, 200))
        tree  = self.vuln_tree if sev == "high" else self.warn_tree

        row = QTreeWidgetItem([
            f"  {sev.upper()}",
            f"  {item['category']}",
            f"  {item['type']}",
            f"  {item['description']}",
        ])
        brush = QBrush(color)
        for col in range(4):
            row.setForeground(col, brush)
        row.setToolTip(3, item.get("recommendation", ""))
        tree.addTopLevelItem(row)

        vc = self.vuln_tree.topLevelItemCount()
        wc = self.warn_tree.topLevelItemCount()
        self.tabs.setTabText(1, f"  Vulnerabilities ({vc})  ")
        self.tabs.setTabText(2, f"  Warnings ({wc})  ")

    def _on_finished(self, results: dict):
        self._results = results
        self.btn_scan.setEnabled(True)
        self.btn_stop.setEnabled(False)
        self.btn_save.setEnabled(True)
        self.progress.setValue(100)

        vc = len(results["vulnerabilities"])
        wc = len(results["warnings"])
        self.sb.showMessage(
            f"Scan complete  ·  {vc} vulnerabilities  ·  {wc} warnings  "
            f"·  Hover descriptions for fix recommendations"
        )
        self._build_summary(results)
        self.tabs.setCurrentIndex(3)

    def _build_summary(self, results: dict):
        si   = results.get("system_info", {})
        vc   = len(results["vulnerabilities"])
        wc   = len(results["warnings"])
        risk = "CRITICAL" if vc > 5 else ("HIGH" if vc > 0 else ("MEDIUM" if wc > 5 else "LOW"))
        risk_color = {"CRITICAL": "#ff2222", "HIGH": "#ff5555",
                      "MEDIUM": "#ff8800", "LOW": "#44cc44"}.get(risk, "#aaa")

        html = f"""
        <style>
          body {{ background:#080808; color:#cccccc;
                  font-family:Consolas,monospace; font-size:10pt; margin:12px; }}
          h2 {{ color:#cc3333; border-bottom:1px solid #3a0000; padding-bottom:6px; }}
          h3 {{ color:#ff6666; margin-top:18px; }}
          table {{ border-collapse:collapse; width:100%; margin-bottom:10px; }}
          td {{ padding:3px 10px; vertical-align:top; }}
          td:first-child {{ color:#884444; width:220px; white-space:nowrap; }}
          .high {{ color:#ff4444; font-weight:bold; }}
          .medium {{ color:#ff8800; font-weight:bold; }}
          .low {{ color:#ffcc00; }}
          .good {{ color:#44cc44; }}
          .rec {{ color:#884444; font-size:9pt; }}
          li {{ margin-bottom:6px; }}
          .risk {{ font-size:14pt; font-weight:bold; color:{risk_color}; }}
        </style>
        <h2>☠  {APP_NAME}  —  Scan Summary</h2>
        <h3>System Information</h3>
        <table>{"".join(f"<tr><td>{k}</td><td>{v}</td></tr>" for k, v in si.items())}</table>

        <h3>Risk Overview</h3>
        <table>
          <tr><td>Overall Risk</td><td class="risk">{risk}</td></tr>
          <tr><td>Vulnerabilities (HIGH)</td>
              <td class="{'high' if vc else 'good'}">{vc}</td></tr>
          <tr><td>Warnings (MEDIUM / LOW)</td>
              <td class="{'medium' if wc else 'good'}">{wc}</td></tr>
        </table>
        """

        if results["vulnerabilities"]:
            html += "<h3>Vulnerabilities</h3><ul>"
            for v in results["vulnerabilities"]:
                html += (
                    f'<li class="high">[HIGH] {v["type"]}: {v["description"]}'
                    + (f'<br><span class="rec">→ {v["recommendation"]}</span>'
                       if v.get("recommendation") else "")
                    + "</li>"
                )
            html += "</ul>"

        if results["warnings"]:
            html += "<h3>Warnings</h3><ul>"
            for w in results["warnings"]:
                cls = "medium" if w["severity"] == "medium" else "low"
                html += (
                    f'<li class="{cls}">[{w["severity"].upper()}] '
                    f'{w["type"]}: {w["description"]}'
                    + (f'<br><span class="rec">→ {w["recommendation"]}</span>'
                       if w.get("recommendation") else "")
                    + "</li>"
                )
            html += "</ul>"

        if results["recommendations"]:
            html += "<h3>General Recommendations</h3><ul>"
            for r in results["recommendations"]:
                html += f"<li>{r}</li>"
            html += "</ul>"

        self.summary.setHtml(html)

    # ── Save ──────────────────────────────────────────────────────────────────

    def _save_report(self):
        if not self._results:
            QMessageBox.warning(self, "No Data", "Run a scan first.")
            return
        path, _ = QFileDialog.getSaveFileName(
            self, "Save Report",
            f"pc_of_death_{datetime.now().strftime('%Y%m%d_%H%M%S')}.txt",
            "Text Report (*.txt);;All Files (*)",
        )
        if not path:
            return
        try:
            with open(path, "w", encoding="utf-8") as f:
                f.write(self._format_text_report())
            QMessageBox.information(self, "Saved", f"Report saved to:\n{path}")
        except Exception as exc:
            QMessageBox.critical(self, "Error", f"Could not save report:\n{exc}")

    def _format_text_report(self) -> str:
        r  = self._results
        si = r.get("system_info", {})
        vc = len(r["vulnerabilities"])
        wc = len(r["warnings"])
        W  = 62
        lines = [
            "=" * W,
            f"  {APP_NAME}  —  {ORG_NAME}",
            f"  Scan time : {r.get('scan_time', 'N/A')}",
            f"  Report    : {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
            "=" * W,
            "",
            "── SYSTEM INFORMATION " + "─" * (W - 22),
        ]
        for k, v in si.items():
            lines.append(f"  {k:<22}{v}")
        lines += [
            "",
            "── RISK OVERVIEW " + "─" * (W - 17),
            f"  Vulnerabilities (HIGH)   : {vc}",
            f"  Warnings (MEDIUM / LOW)  : {wc}",
            "",
        ]
        if r["vulnerabilities"]:
            lines.append("── VULNERABILITIES " + "─" * (W - 19))
            for i, v in enumerate(r["vulnerabilities"], 1):
                lines += [
                    f"  {i}. [HIGH] {v['type']}",
                    f"     Category : {v['category']}",
                    f"     Detail   : {v['description']}",
                ]
                if v.get("recommendation"):
                    lines.append(f"     Fix      : {v['recommendation']}")
                lines.append("")
        if r["warnings"]:
            lines.append("── WARNINGS " + "─" * (W - 12))
            for i, w in enumerate(r["warnings"], 1):
                lines += [
                    f"  {i}. [{w['severity'].upper()}] {w['type']}",
                    f"     Category : {w['category']}",
                    f"     Detail   : {w['description']}",
                ]
                if w.get("recommendation"):
                    lines.append(f"     Fix      : {w['recommendation']}")
                lines.append("")
        if r["recommendations"]:
            lines.append("── RECOMMENDATIONS " + "─" * (W - 19))
            for i, rec in enumerate(r["recommendations"], 1):
                lines.append(f"  {i}. {rec}")
            lines.append("")
        lines += [
            "── FULL SCAN LOG " + "─" * (W - 17),
            "",
            self.log_view.toPlainText(),
            "",
            "=" * W,
            f"  End of report  —  {APP_NAME}  —  {ORG_NAME}",
            "=" * W,
        ]
        return "\n".join(lines)

    # ── Clear ─────────────────────────────────────────────────────────────────

    def _clear(self):
        self.log_view.clear()
        self.vuln_tree.clear()
        self.warn_tree.clear()
        self.summary.clear()
        self.progress.setValue(0)
        self.tabs.setTabText(1, "  Vulnerabilities  ")
        self.tabs.setTabText(2, "  Warnings  ")
        self.sb.showMessage("Ready — click  ▶ START SCAN  to begin")
        self._results = None
        self.btn_save.setEnabled(False)


# =============================================================================
# Entry Point
# =============================================================================

def main():
    app = QApplication(sys.argv)
    app.setApplicationName(APP_NAME)
    app.setOrganizationName(ORG_NAME)
    app.setStyleSheet(DARK_STYLE)

    splash = create_splash()
    if splash:
        splash.show()
        messages = [
            "Initializing…",
            "Loading security modules…",
            "Preparing vulnerability checks…",
            "Ready.",
        ]
        for msg in messages:
            splash.showMessage(
                "\n\n\n\n\n\n\n" + msg,
                Qt.AlignmentFlag.AlignBottom | Qt.AlignmentFlag.AlignCenter,
                QColor(255, 255, 255),
            )
            app.processEvents()
            time.sleep(0.4)

    win = MainWindow()
    win.show()

    if splash:
        splash.finish(win)

    sys.exit(app.exec())


if __name__ == "__main__":
    main()
